

#include <stdio.h>   // Necessário para FILE, fopen, fread, fwrite, fclose, printf
#include <string.h>  // Se estiver usando strcmp
#include "db.h"      // Seu header com struct Ocorrencia e protótipos


int main(void) {
    db_init();

    Ocorrencia o1 = {0, "09/02/2026", "Jose", "Furto", 0, 4, 1};
    Ocorrencia o2 = {0, "10/02/2026", "Pedro", "Roubo", 0, 3, 1};
    Ocorrencia o3 = {0, "11/02/2026", "Mario", "Furto", 0, 3, 1};

    db_create(&o1);
    db_create(&o2);
    db_create(&o3);

    printf("\n=== LISTA COMPLETA ===\n");
    db_list_all();

    printf("\n=== ORDENADO POR ID ===\n");
    db_list_sorted_by_id();

    printf("\n=== ORDENADO POR DATA ===\n");
    db_list_sorted_by_date();

    // Testando consulta e libertação
    db_consultar_por_id_e_liberar(2);

    printf("\n=== LISTA ATUALIZADA ===\n");
    db_list_all();

    printf("\nPressione Enter para sair...");
    getchar();
    getchar();

    return 0;
}

