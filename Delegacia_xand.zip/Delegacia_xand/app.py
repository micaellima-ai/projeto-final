import tkinter as tk
from tkinter import messagebox, ttk
from PIL import Image, ImageTk
import db_service as db

db.iniciar_banco()

# ================= FUNÇÕES =================
def atualizar_registros():
    registros = db.listar_ativos()
    lista_registros.delete(0, tk.END)

    for r in registros:
        lista_registros.insert(
            tk.END,
            f"ID:{r['id']} | {r['nome']} | Cela:{r['cela']} | ATIVO"
        )

    lbl_ativos.config(text=f"Ativos: {len(registros)}")

def atualizar_historico():
    lista_historico.delete(0, tk.END)
    registros = db.listar_todos()

    for r in registros:
        status = "ATIVO" if r["ativo"] else "LIBERADO"
        lista_historico.insert(
            tk.END,
            f"ID:{r['id']} | {r['nome']} | Cela:{r['cela']} | {status}"
        )

    lbl_total.config(text=f"Total: {len(registros)}")

def inserir_ocorrencia():
    try:
        db.inserir_ocorrencia(
            entry_dia.get(), entry_mes.get(), entry_ano.get(),
            entry_nome.get(), combo_crime.get(), 0, int(entry_cela.get())
        )
        atualizar_registros()
        atualizar_historico()
        messagebox.showinfo("Sucesso", "Ocorrência cadastrada!")
    except:
        messagebox.showerror("Erro", "Preencha corretamente!")

def liberar_selecionado():
    selecionado = lista_registros.curselection()
    if not selecionado:
        messagebox.showwarning("Aviso", "Selecione um registro")
        return

    item = lista_registros.get(selecionado[0])
    id_registro = int(item.split("|")[0].replace("ID:", "").strip())

    if messagebox.askyesno("Confirmar", "Deseja liberar este suspeito?"):
        if db.consultar_e_liberar(id_registro):
            atualizar_registros()
            atualizar_historico()
            messagebox.showinfo("Sucesso", "Suspeito liberado")

def buscar_por_nome():
    termo = entry_buscar_nome.get().strip().lower()
    lista_registros.delete(0, tk.END)

    registros = db.listar_ativos()
    encontrados = [r for r in registros if termo in r["nome"].lower()]

    for r in encontrados:
        lista_registros.insert(
            tk.END,
            f"ID:{r['id']} | {r['nome']} | Cela:{r['cela']} | ATIVO"
        )

def resetar_banco_ui():
    if messagebox.askyesno("Confirmação", "Deseja apagar todos os registros?"):
        db.resetar_banco()
        atualizar_registros()
        atualizar_historico()

# ================= JANELA =================
root = tk.Tk()
root.title("Sistema de Monitoramento")
root.geometry("900x720")

canvas = tk.Canvas(root, highlightthickness=0)
canvas.pack(fill="both", expand=True)

# ================= FUNDO =================
img_orig = Image.open("download.png")
bg_image = None

def redimensionar(event):
    global bg_image
    w, h = event.width, event.height

    img = img_orig.resize((w, h), Image.LANCZOS)
    bg_image = ImageTk.PhotoImage(img)

    canvas.delete("bg")
    canvas.create_image(0, 0, image=bg_image, anchor="nw", tags="bg")

    sidebar = Image.new("RGBA", (240, h), (0, 0, 0, 210))
    sidebar_img = ImageTk.PhotoImage(sidebar)
    canvas.create_image(0, 0, image=sidebar_img, anchor="nw", tags="bg")
    canvas.sidebar_img = sidebar_img

    # reposiciona histórico (inferior direito)
    canvas.coords(
        historico_label,
        w - 430,
        h - 300
    )
    canvas.coords(
        historico_window,
        w - 430,
        h - 275
    )

    canvas.tag_raise("ui")

canvas.bind("<Configure>", redimensionar)

# ================= ESTILO =================
fg = "#FFFFFF"
bg_entry = "#1b1b1b"

def aplicar_focus(entry):
    entry.bind("<FocusIn>", lambda e: entry.config(highlightthickness=2, highlightbackground="#b30000"))
    entry.bind("<FocusOut>", lambda e: entry.config(highlightthickness=0))

def label(x, y, texto):
    return canvas.create_text(
        x, y, text=texto, fill=fg,
        font=("Arial", 12, "bold"),
        anchor="w", tags="ui"
    )

x = 5

# ================= UI =================
label(x, 40, "NOME DO SUSPEITO")
entry_nome = tk.Entry(root, bg=bg_entry, fg="white", font=("Arial", 11), bd=0)
aplicar_focus(entry_nome)
canvas.create_window(x, 65, window=entry_nome, width=300, anchor="w", tags="ui")

label(x, 110, "CRIME")
combo_crime = ttk.Combobox(root, values=["Furto", "Roubo"], state="readonly")
canvas.create_window(x, 135, window=combo_crime, width=300, anchor="w", tags="ui")

label(x, 180, "DATA")
f_data = tk.Frame(root, bg="#000")
entry_dia = tk.Entry(f_data, width=3, bg=bg_entry, fg="white", bd=0)
entry_mes = tk.Entry(f_data, width=3, bg=bg_entry, fg="white", bd=0)
entry_ano = tk.Entry(f_data, width=5, bg=bg_entry, fg="white", bd=0)
for e in (entry_dia, entry_mes, entry_ano):
    aplicar_focus(e)
    e.pack(side="left")
tk.Label(f_data, text="/", bg="#000", fg="white").pack(side="left")
tk.Label(f_data, text="/", bg="#000", fg="white").pack(side="left")
canvas.create_window(x, 205, window=f_data, anchor="w", tags="ui")

label(x, 250, "CELA")
entry_cela = tk.Entry(root, bg=bg_entry, fg="white", font=("Arial", 11), bd=0)
aplicar_focus(entry_cela)
canvas.create_window(x, 275, window=entry_cela, width=300, anchor="w", tags="ui")

btn = tk.Button(root, text="REGISTRAR (Ctrl+Enter)",
                command=inserir_ocorrencia,
                bg="#b30000", fg="white",
                font=("Arial", 11, "bold"), bd=0)
canvas.create_window(x, 330, window=btn, width=300, anchor="w", tags="ui")

# ================= CONTADORES =================
lbl_ativos = tk.Label(root, text="Ativos: 0", fg="#00ff00", bg="#000", font=("Arial", 10, "bold"))
lbl_total = tk.Label(root, text="Total: 0", fg="#ffaa00", bg="#000", font=("Arial", 10, "bold"))
canvas.create_window(x, 370, window=lbl_ativos, anchor="w", tags="ui")
canvas.create_window(x + 140, 370, window=lbl_total, anchor="w", tags="ui")

# ================= LISTA ATIVOS =================
label(x, 410, "ATIVOS")
lista_registros = tk.Listbox(root, height=8, width=42,
                             bg="#000", fg="#00ff00",
                             font=("Consolas", 9),
                             selectbackground="#b30000", bd=0)
canvas.create_window(x, 485, window=lista_registros, anchor="w", tags="ui")

btn_liberar = tk.Button(root, text="LIBERAR (Del)",
                        command=liberar_selecionado,
                        bg="#444", fg="white", bd=0)
canvas.create_window(x, 640, window=btn_liberar, width=300, anchor="w", tags="ui")

# ================= HISTÓRICO (DIREITA INFERIOR) =================
historico_label = label(0, 0, "HISTÓRICO COMPLETO")

lista_historico = tk.Listbox(root, height=8, width=42,
                             bg="#000", fg="#ffffff",
                             font=("Consolas", 9),
                             bd=0)
historico_window = canvas.create_window(
    0, 0, window=lista_historico, anchor="nw", tags="ui"
)

# ================= BUSCA =================
label(x, 670, "BUSCAR NOME")
entry_buscar_nome = tk.Entry(root, bg=bg_entry, fg="white", bd=0)
aplicar_focus(entry_buscar_nome)
canvas.create_window(x, 695, window=entry_buscar_nome, width=200, anchor="w", tags="ui")

btn_buscar = tk.Button(root, text="BUSCAR",
                       command=buscar_por_nome,
                       bg="#444", fg="white", bd=0)
canvas.create_window(x + 210, 695, window=btn_buscar, width=90, anchor="w", tags="ui")

# ================= ATALHOS =================
root.bind("<Control-Return>", lambda e: inserir_ocorrencia())
root.bind("<Delete>", lambda e: liberar_selecionado())
root.bind("<F5>", lambda e: atualizar_registros())

# ================= INIT =================
atualizar_registros()
atualizar_historico()
root.mainloop()
