#ifndef DB_H
#define DB_H
// Diretivas de proteção (include guard)
// Evitam que o arquivo seja incluído mais de uma vez no mesmo projeto

#include <stdio.h>   // Para uso de FILE, fopen, fread, fwrite, fclose, printf
#include <string.h>  // Para manipulação de strings (ex: strcmp)

// ❌ ERRO: não se inclui o próprio header dentro dele mesmo
// #include "db.h"   --> REMOVER ESTA LINHA

#define DB_FILE "delegacia.bin"
// Define o nome do arquivo binário onde os dados serão armazenados

#define MAX_OCORRENCIAS 100
// Define o número máximo de ocorrências suportadas no sistema

// Estrutura que representa uma ocorrência policial
typedef struct {
    int id_ocorrencia;        // Identificador único da ocorrência

    char data_entrada[11];    // Data no formato DD/MM/AAAA
                               // 10 caracteres + 1 para o '\0'

    char nome[50];            // Nome da pessoa envolvida

    char tipo_crime[20];      // Tipo do crime (ex: Furto, Roubo)

    int status;               // Situação do preso:
                              // 0 = Preso
                              // 1 = Solto

    int cela;                 // Número da cela onde está preso

    int ativo;                // Controle lógico do registro:
                              // 1 = ativo
                              // 0 = inativo (removido logicamente)
} Ocorrencia;


/* ===== Protótipos das funções do banco de dados ===== */

// Inicializa o banco (ex: cria o arquivo se não existir)
int db_init(void);

// Gera um novo ID automaticamente
int gerador_de_ID(void);

// Cria (insere) uma nova ocorrência no arquivo
int db_create(Ocorrencia *o);

// Lê uma ocorrência pelo ID
// id  -> ID a ser buscado
// out -> estrutura onde os dados serão copiados
int db_read(int id, Ocorrencia *out);

// Consulta uma ocorrência pelo ID e altera seu status para "liberado"
int db_consultar_por_id_e_liberar(int id);

#endif
// Fim do include guard
