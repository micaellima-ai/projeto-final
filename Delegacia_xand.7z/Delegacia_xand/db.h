#ifndef DB_H
#define DB_H


#include <stdio.h>   // Necessário para FILE, fopen, fread, fwrite, fclose, printf
#include <string.h>  // Se estiver usando strcmp
#include "db.h"      // Seu header com struct Ocorrencia e protótipos


#define DB_FILE "delegacia.bin"
#define MAX_OCORRENCIAS 100

typedef struct {
    int id_ocorrencia;
    char data_entrada[11];   // DD/MM/AAAA
    char nome[50];
    char tipo_crime[20];
    int status;              // 0=Preso | 1=Solto
    int cela;
    int ativo;               // 1=ativo | 0=inativo
} Ocorrencia;

/* Funções do banco */
int db_init(void);
int gerador_de_ID(void);
int db_create(Ocorrencia *o);
int db_read(int id, Ocorrencia *out);
int db_consultar_por_id_e_liberar(int id);

#endif
