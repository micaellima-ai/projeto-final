#ifndef DB_H
#define DB_H

#include <stdio.h>

#define DB_FILE "delegacia.bin"

/*
   IMPORTANTE:
   __attribute__((packed)) garante que a struct
   não terá padding. Essencial para funcionar
   corretamente com Python + ctypes.
*/

typedef struct __attribute__((packed)) {
    int id_ocorrencia;      // 4 bytes
    char data_entrada[11];  // 11 bytes
    char nome[50];          // 50 bytes
    char tipo_crime[20];    // 20 bytes
    int status;             // 4 bytes
    int cela;               // 4 bytes
    int ativo;              // 4 bytes
} Ocorrencia;

/* Protótipos */
int db_init(void);
int gerador_de_ID(void);
int db_create(Ocorrencia *o);
int db_read(int id, Ocorrencia *out);
int db_consultar_por_id_e_liberar(int id);

#endif
