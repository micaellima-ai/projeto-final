import tkinter as tk
from tkinter import messagebox, ttk
import db_service as db


# ================= FUNÇÕES =================
def atualizar_registros():
    registros = db.listar_ativos()

    for item in tabela_ativos.get_children():
        tabela_ativos.delete(item)

    for r in registros:
        tabela_ativos.insert(
            "", "end",
            values=(r["id"], r["data"], r["nome"], r["crime"], r["cela"], "ATIVO")
        )

    lbl_ativos.config(text=f"Ativos: {len(registros)}")


def inserir_ocorrencia():
    try:
        db.inserir_ocorrencia(
            entry_dia.get(),
            entry_mes.get(),
            entry_ano.get(),
            entry_nome.get(),
            combo_crime.get(),
            1,
            entry_cela.get()  # agora validado dentro do db_service
        )

        atualizar_registros()

        messagebox.showinfo("Sucesso", "Ocorrência cadastrada com sucesso!")

        entry_dia.delete(0, tk.END)
        entry_mes.delete(0, tk.END)
        entry_ano.delete(0, tk.END)
        entry_nome.delete(0, tk.END)
        entry_cela.delete(0, tk.END)
        combo_crime.set("")

    except Exception as e:
        messagebox.showerror("Erro", str(e))


# ================= POPUPS =================
def buscar_por_id_popup():
    popup = tk.Toplevel(root)
    popup.title("Buscar por ID")
    popup.geometry("320x200")

    tk.Label(popup, text="Digite o ID:", font=("Calibri", 11)).pack(pady=10)
    entry_id = tk.Entry(popup, width=20)
    entry_id.pack(pady=5)

    def buscar():
        try:
            registro = db.consultar_por_id(int(entry_id.get()))
            if registro:
                messagebox.showinfo(
                    "Resultado",
                    f"ID: {registro['id']}\n"
                    f"Nome: {registro['nome']}\n"
                    f"Crime: {registro['crime']}\n"
                    f"Cela: {registro['cela']}\n"
                    f"Data: {registro['data']}\n"
                    f"Status: {'ATIVO' if registro['ativo'] else 'LIBERADO'}"
                )
            else:
                messagebox.showerror("Erro", "ID não encontrado.")
        except Exception:
            messagebox.showerror("Erro", "ID inválido.")

    tk.Button(popup, text="Buscar", width=15, command=buscar).pack(pady=15)


def liberar_por_id_popup():
    popup = tk.Toplevel(root)
    popup.title("Liberar Suspeito")
    popup.geometry("350x250")

    tk.Label(popup, text="Digite o ID para liberar:", font=("Calibri", 11)).pack(pady=10)
    entry_id = tk.Entry(popup, width=20)
    entry_id.pack(pady=5)

    def buscar_e_confirmar():
        try:
            id_digitado = int(entry_id.get())
            registro = db.consultar_por_id(id_digitado)

            if not registro:
                messagebox.showerror("Erro", "ID não encontrado.")
                return

            if not registro["ativo"]:
                messagebox.showerror("Erro", "Este suspeito já foi liberado.")
                return

            confirmacao = messagebox.askyesno(
                "Confirmar Liberação",
                f"ID: {registro['id']}\n"
                f"Nome: {registro['nome']}\n"
                f"Crime: {registro['crime']}\n"
                f"Cela: {registro['cela']}\n"
                f"Data: {registro['data']}\n\n"
                f"Deseja realmente liberar?"
            )

            if confirmacao:
                sucesso = db.consultar_e_liberar(id_digitado)

                if sucesso:
                    atualizar_registros()
                    messagebox.showinfo("Sucesso", "Suspeito liberado com sucesso!")
                    popup.destroy()
                else:
                    messagebox.showerror("Erro", "Erro ao liberar.")

        except Exception:
            messagebox.showerror("Erro", "ID inválido.")

    tk.Button(popup, text="Buscar", width=15, command=buscar_e_confirmar).pack(pady=20)


# ================= HISTÓRICO =================
def historico_popup():
    popup = tk.Toplevel(root)
    popup.title("Histórico Completo")
    popup.geometry("1000x500")

    lbl_total_popup = tk.Label(popup, text="", font=("Calibri", 12, "bold"))
    lbl_total_popup.pack(pady=10)

    colunas = ("ID", "Data", "Nome", "Crime", "Cela", "Status")
    tabela = ttk.Treeview(popup, columns=colunas, show="headings", height=15)

    for col in colunas:
        tabela.heading(col, text=col)
        tabela.column(col, width=150, anchor="center")

    tabela.pack(pady=10, fill="both", expand=True, padx=20)

    scrollbar = ttk.Scrollbar(popup, orient="vertical", command=tabela.yview)
    tabela.configure(yscroll=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    registros = db.listar_todos()

    for r in registros:
        status = "ATIVO" if r["ativo"] else "LIBERADO"
        tabela.insert(
            "", "end",
            values=(r["id"], r["data"], r["nome"], r["crime"], r["cela"], status)
        )

    lbl_total_popup.config(text=f"Total de Registros: {len(registros)}")


# ================= JANELA PRINCIPAL =================
root = tk.Tk()
root.title("Sistema de Monitoramento")
root.geometry("1300x800")


# ================= BARRA SUPERIOR =================
barra_topo = tk.Frame(root, bg="#e6e6e6", height=50)
barra_topo.pack(fill="x")

titulo_barra = tk.Label(
    barra_topo,
    text="Sistema Delegacia - Painel Administrativo",
    bg="#e6e6e6",
    fg="black",
    font=("Calibri", 12, "bold")
)
titulo_barra.pack(side="left", padx=20)

btn_ver_historico = tk.Button(
    barra_topo,
    text="Ver Histórico",
    bg="#d9d9d9",
    relief="flat",
    width=15,
    command=historico_popup
)
btn_ver_historico.pack(side="left", padx=10)

btn_buscar_id = tk.Button(
    barra_topo,
    text="Buscar por ID",
    bg="#d9d9d9",
    relief="flat",
    width=15,
    command=buscar_por_id_popup
)
btn_buscar_id.pack(side="left", padx=10)

btn_liberar_topo = tk.Button(
    barra_topo,
    text="Liberar Suspeito",
    bg="#FFFFFF",
    relief="flat",
    width=15,
    command=liberar_por_id_popup
)
btn_liberar_topo.pack(side="left", padx=10)


# ================= ESTILO =================
style = ttk.Style()
style.theme_use("clam")

style.configure("Treeview",
                background="#ffffff",
                foreground="black",
                rowheight=28,
                fieldbackground="#ffffff",
                font=("Calibri", 11))

style.configure("Treeview.Heading",
                background="#ffffff",
                foreground="black",
                font=("Calibri", 11, "bold"))


# ================= FORMULÁRIO =================
frame_form = tk.Frame(root)
frame_form.pack(pady=40)

tk.Label(frame_form, text="Data", font=("Calibri", 12)).grid(row=0, column=0, padx=15)

entry_dia = tk.Entry(frame_form, width=8)
entry_dia.grid(row=0, column=1)
tk.Label(frame_form, text="/").grid(row=0, column=2)

entry_mes = tk.Entry(frame_form, width=8)
entry_mes.grid(row=0, column=3)
tk.Label(frame_form, text="/").grid(row=0, column=4)

entry_ano = tk.Entry(frame_form, width=10)
entry_ano.grid(row=0, column=5)

tk.Label(frame_form, text="Nome", font=("Calibri", 12)).grid(row=1, column=0, pady=15)
entry_nome = tk.Entry(frame_form, width=50)
entry_nome.grid(row=1, column=1, columnspan=5)

tk.Label(frame_form, text="Crime", font=("Calibri", 12)).grid(row=2, column=0, pady=15)
combo_crime = ttk.Combobox(frame_form, values=["Furto", "Roubo"], state="readonly", width=47)
combo_crime.grid(row=2, column=1, columnspan=5)

tk.Label(frame_form, text="Cela", font=("Calibri", 12)).grid(row=3, column=0, pady=15)
entry_cela = tk.Entry(frame_form, width=20)
entry_cela.grid(row=3, column=1, columnspan=5)

tk.Button(frame_form, text="Registrar", width=25, height=2,
          command=inserir_ocorrencia).grid(row=4, column=0, columnspan=6, pady=25)

lbl_ativos = tk.Label(root, text="Ativos: 0", font=("Calibri", 12, "bold"))
lbl_ativos.pack(pady=10)


# ================= TABELA ATIVOS =================
colunas_ativos = ("ID", "Data", "Nome", "Crime", "Cela", "Status")
tabela_ativos = ttk.Treeview(root, columns=colunas_ativos, show="headings", height=8)

for col in colunas_ativos:
    tabela_ativos.heading(col, text=col)
    tabela_ativos.column(col, width=150, anchor="center")

tabela_ativos.pack(pady=5, fill="x", padx=100)


# ================= INICIALIZAÇÃO =================
atualizar_registros()
root.mainloop()
