import tkinter as tk
from tkinter import messagebox, ttk
from PIL import Image, ImageTk
import db_service as db

db.iniciar_banco()

# ================= FUNÇÕES ORIGINAIS =================
def atualizar_registros():
    registros = db.listar_ativos()

    for item in tabela_ativos.get_children():
        tabela_ativos.delete(item)

    for r in registros:
        tabela_ativos.insert(
            "", "end",
            values=(r["id"], r["nome"], r["cela"], "ATIVO")
        )

    lbl_ativos.config(text=f"Ativos: {len(registros)}")


def atualizar_historico():
    registros = db.listar_todos()

    for item in tabela_historico.get_children():
        tabela_historico.delete(item)

    for r in registros:
        status = "ATIVO" if r["ativo"] else "LIBERADO"

        tabela_historico.insert(
            "", "end",
            values=(
                r["id"],
                r["data"],
                r["nome"],
                r["crime"],
                r["cela"],
                status
            )
        )

    lbl_total.config(text=f"Total: {len(registros)}")


def inserir_ocorrencia():
    try:
        db.inserir_ocorrencia(
            entry_dia.get(), entry_mes.get(), entry_ano.get(),
            entry_nome.get(), combo_crime.get(), 0, int(entry_cela.get())
        )
        atualizar_registros()
        atualizar_historico()
        messagebox.showinfo("Sucesso", "Ocorrência cadastrada!")
    except Exception as e:
        messagebox.showerror("Erro", str(e))


# ================= NOVAS FUNÇÕES MENU =================
def buscar_por_id_popup():
    popup = tk.Toplevel(root)
    popup.title("Buscar por ID")
    popup.geometry("300x180")

    tk.Label(popup, text="Digite o ID:").pack(pady=5)
    entry_id = tk.Entry(popup)
    entry_id.pack(pady=5)

    def buscar():
        try:
            registro = db.consultar_por_id(int(entry_id.get()))
            if registro:
                messagebox.showinfo(
                    "Resultado",
                    f"ID: {registro['id']}\n"
                    f"Nome: {registro['nome']}\n"
                    f"Crime: {registro['crime']}\n"
                    f"Cela: {registro['cela']}\n"
                    f"Data: {registro['data']}"
                )
            else:
                messagebox.showerror("Erro", "ID não encontrado.")
        except:
            messagebox.showerror("Erro", "ID inválido.")

    tk.Button(popup, text="Buscar", command=buscar).pack(pady=10)


def liberar_por_id_popup():
    popup = tk.Toplevel(root)
    popup.title("Liberar Suspeito")
    popup.geometry("300x180")

    tk.Label(popup, text="Digite o ID para liberar:").pack(pady=5)
    entry_id = tk.Entry(popup)
    entry_id.pack(pady=5)

    def liberar():
        try:
            sucesso = db.consultar_e_liberar(int(entry_id.get()))
            if sucesso:
                atualizar_registros()
                atualizar_historico()
                messagebox.showinfo("Sucesso", "Suspeito liberado!")
                popup.destroy()
            else:
                messagebox.showerror("Erro", "ID inválido ou já liberado.")
        except:
            messagebox.showerror("Erro", "ID inválido.")

    tk.Button(popup, text="Liberar", command=liberar).pack(pady=10)


# ================= JANELA =================
root = tk.Tk()
root.title("Sistema de Monitoramento")
root.geometry("1100x750")

# ================= BARRA SUPERIOR ESTILO EXCEL =================
barra_topo = tk.Frame(root, bg="#e6e6e6", height=40)
barra_topo.pack(fill="x")

titulo_barra = tk.Label(
    barra_topo,
    text="Sistema Delegacia - Painel Administrativo",
    bg="#e6e6e6",
    fg="black",
    font=("Calibri", 11, "bold")
)
titulo_barra.pack(side="left", padx=15)

btn_ver_historico = tk.Button(
    barra_topo,
    text="Ver Histórico",
    bg="#d9d9d9",
    relief="flat",
    command=atualizar_historico
)
btn_ver_historico.pack(side="left", padx=5)

btn_buscar_id = tk.Button(
    barra_topo,
    text="Buscar por ID",
    bg="#d9d9d9",
    relief="flat",
    command=buscar_por_id_popup
)
btn_buscar_id.pack(side="left", padx=5)

btn_liberar_topo = tk.Button(
    barra_topo,
    text="Liberar Suspeito",
    bg="#d9d9d9",
    relief="flat",
    command=liberar_por_id_popup
)
btn_liberar_topo.pack(side="left", padx=5)

# ================= ESTILO TABELA =================
style = ttk.Style()
style.theme_use("clam")

style.configure("Treeview",
                background="#ffffff",
                foreground="black",
                rowheight=25,
                fieldbackground="#ffffff",
                font=("Calibri", 10))

style.configure("Treeview.Heading",
                background="#e6e6e6",
                foreground="black",
                font=("Calibri", 10, "bold"))

# ================= FORM =================
frame_form = tk.Frame(root)
frame_form.pack(pady=15)

tk.Label(frame_form, text="Nome").grid(row=0, column=0)
entry_nome = tk.Entry(frame_form)
entry_nome.grid(row=0, column=1)

tk.Label(frame_form, text="Crime").grid(row=1, column=0)
combo_crime = ttk.Combobox(frame_form, values=["Furto", "Roubo"], state="readonly")
combo_crime.grid(row=1, column=1)

tk.Label(frame_form, text="Dia").grid(row=2, column=0)
entry_dia = tk.Entry(frame_form, width=3)
entry_dia.grid(row=2, column=1, sticky="w")

entry_mes = tk.Entry(frame_form, width=3)
entry_mes.grid(row=2, column=1)

entry_ano = tk.Entry(frame_form, width=5)
entry_ano.grid(row=2, column=1, sticky="e")

tk.Label(frame_form, text="Cela").grid(row=3, column=0)
entry_cela = tk.Entry(frame_form)
entry_cela.grid(row=3, column=1)

tk.Button(frame_form, text="Registrar", command=inserir_ocorrencia).grid(row=4, columnspan=2, pady=10)

lbl_ativos = tk.Label(root, text="Ativos: 0")
lbl_ativos.pack()

# ================= TABELA ATIVOS =================
colunas_ativos = ("ID", "Nome", "Cela", "Status")
tabela_ativos = ttk.Treeview(root, columns=colunas_ativos, show="headings", height=6)

for col in colunas_ativos:
    tabela_ativos.heading(col, text=col)
    tabela_ativos.column(col, width=150, anchor="center")

tabela_ativos.pack(pady=10)

lbl_total = tk.Label(root, text="Total: 0")
lbl_total.pack()

# ================= TABELA HISTÓRICO =================
colunas_hist = ("ID", "Data", "Nome", "Crime", "Cela", "Status")
tabela_historico = ttk.Treeview(root, columns=colunas_hist, show="headings", height=8)

for col in colunas_hist:
    tabela_historico.heading(col, text=col)
    tabela_historico.column(col, width=150, anchor="center")

tabela_historico.pack(pady=10)

# ================= INIT =================
atualizar_registros()
atualizar_historico()

root.mainloop()
