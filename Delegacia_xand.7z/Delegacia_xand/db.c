#include "db.h"      // Inclui a definição da struct Ocorrencia e os protótipos das funções
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* =====================================================
   FUNÇÃO: db_init
   OBJETIVO: Inicializar o banco de dados
   DESCRIÇÃO: Cria o arquivo binário caso ele não exista.
   ===================================================== */
int db_init(void) {

    // "ab+" → Abre para leitura e escrita em modo binário.
    // Se o arquivo não existir, ele será criado.
    FILE *f = fopen(DB_FILE, "ab+");

    // Verifica se houve erro na abertura/criação do arquivo
    if (!f) 
        return 0;  // Retorna 0 indicando falha

    fclose(f);     // Fecha o arquivo
    return 1;      // Retorna 1 indicando sucesso
}


/* =====================================================
   FUNÇÃO: gerador_de_ID
   OBJETIVO: Gerar automaticamente um novo ID
   DESCRIÇÃO: Percorre o arquivo procurando o maior ID
              já existente e retorna o próximo disponível.
   ===================================================== */
int gerador_de_ID(void) {

    FILE *f = fopen(DB_FILE, "rb");  // Abre somente para leitura binária

    // Se o arquivo não existir, o primeiro ID será 1
    if (!f) 
        return 1;

    Ocorrencia o;   // Variável auxiliar para leitura
    int max_id = 0; // Guarda o maior ID encontrado

    // Lê registro por registro até o final do arquivo
    while (fread(&o, sizeof(Ocorrencia), 1, f)) {

        // Se encontrar um ID maior que o atual máximo
        if (o.id_ocorrencia > max_id)
            max_id = o.id_ocorrencia;
    }

    fclose(f);  // Fecha o arquivo

    // Retorna o próximo ID disponível
    return max_id + 1;
}


/* =====================================================
   FUNÇÃO: db_create
   OBJETIVO: Inserir uma nova ocorrência no banco
   DESCRIÇÃO: Gera um ID automaticamente e grava o
              registro no final do arquivo.
   ===================================================== */
int db_create(Ocorrencia *o) {

    FILE *f = fopen(DB_FILE, "ab");  // Abre para escrita no final do arquivo

    if (!f) 
        return 0;  // Erro ao abrir arquivo

    // Gera ID automático
    o->id_ocorrencia = gerador_de_ID();

    // Marca o registro como ativo
    o->ativo = 1;

    // Escreve a struct inteira no arquivo binário
    fwrite(o, sizeof(Ocorrencia), 1, f);

    fclose(f);  // Fecha o arquivo

    return 1;   // Sucesso
}


/* =====================================================
   FUNÇÃO: db_read
   OBJETIVO: Consultar ocorrência pelo ID
   DESCRIÇÃO: Procura um registro ativo com o ID
              informado e copia os dados para 'out'.
   ===================================================== */
int db_read(int id, Ocorrencia *out) {

    FILE *f = fopen(DB_FILE, "rb");  // Abre para leitura

    if (!f) 
        return 0;

    Ocorrencia temp;  // Variável auxiliar

    // Percorre todo o arquivo
    while (fread(&temp, sizeof(Ocorrencia), 1, f)) {

        // Verifica se o ID corresponde e está ativo
        if (temp.id_ocorrencia == id && temp.ativo) {

            *out = temp;  // Copia os dados encontrados
            fclose(f);
            return 1;     // Registro encontrado
        }
    }

    fclose(f);
    return 0;  // Registro não encontrado
}


/* =====================================================
   FUNÇÃO: db_consultar_por_id_e_liberar
   OBJETIVO: Consultar um suspeito e liberá-lo
   DESCRIÇÃO: Exibe os dados do suspeito e, se o
              usuário confirmar, altera o status
              para "Solto" e realiza exclusão lógica.
   ===================================================== */
int db_consultar_por_id_e_liberar(int id) {

    FILE *f = fopen(DB_FILE, "rb+");  
    // "rb+" → leitura e escrita binária (permite sobrescrever)

    if (!f) 
        return 0;

    Ocorrencia o;

    // Percorre todo o arquivo
    while (fread(&o, sizeof(Ocorrencia), 1, f)) {

        // Verifica se encontrou o ID desejado e está ativo
        if (o.id_ocorrencia == id && o.ativo) {

            // Exibe os dados do suspeito
            printf("\n=== FICHA DO SUSPEITO ===\n");
            printf("ID: %d\n", o.id_ocorrencia);
            printf("Data: %s\n", o.data_entrada);
            printf("Nome: %s\n", o.nome);
            printf("Crime: %s\n", o.tipo_crime);
            printf("Status: %s\n", o.status == 0 ? "Preso" : "Solto");
            printf("Cela: %d\n", o.cela);

            int opcao;

            // Pergunta ao usuário se deseja liberar
            printf("\nDeseja libertar este suspeito?\n1 - Sim\n0 - Não\nOpcao: ");
            scanf("%d", &opcao);
            getchar(); // Limpa o buffer do teclado

            if (opcao == 1) {

                // Atualiza os dados
                o.status = 1;  // Marca como Solto
                o.ativo = 0;   // Exclusão lógica (registro inativo)

                // Volta o ponteiro do arquivo para a posição
                // do registro atual para sobrescrevê-lo
                fseek(f, -(long)sizeof(Ocorrencia), SEEK_CUR);

                // Reescreve o registro atualizado
                fwrite(&o, sizeof(Ocorrencia), 1, f);

                fclose(f);

                printf("\nSuspeito libertado e ficha removida com sucesso.\n");

                return 1;
            }

            fclose(f);
            printf("\nOperação cancelada.\n");
            return 1;
        }
    }

    fclose(f);

    printf("\nOcorrência não encontrada.\n");
    return 0;
}
