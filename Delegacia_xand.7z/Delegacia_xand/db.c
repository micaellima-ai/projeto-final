#include "db.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* =====================================================
   FUNÇÃO: db_init
   OBJETIVO: Inicializar o banco de dados
   ===================================================== */
int db_init(void) {

    FILE *f = fopen(DB_FILE, "ab+");

    if (!f)
        return 0;

    fclose(f);
    return 1;
}


/* =====================================================
   FUNÇÃO: gerador_de_ID
   OBJETIVO: Gerar automaticamente um novo ID
   ===================================================== */
int gerador_de_ID(void) {

    FILE *f = fopen(DB_FILE, "rb");

    if (!f)
        return 1;

    Ocorrencia o;
    int max_id = 0;

    while (fread(&o, sizeof(Ocorrencia), 1, f) == 1) {

        if (o.id_ocorrencia > max_id)
            max_id = o.id_ocorrencia;
    }

    fclose(f);

    return max_id + 1;
}


/* =====================================================
   FUNÇÃO: db_create
   OBJETIVO: Inserir nova ocorrência
   ===================================================== */
int db_create(Ocorrencia *o) {

    FILE *f = fopen(DB_FILE, "ab");

    if (!f)
        return 0;

    o->id_ocorrencia = gerador_de_ID();
    o->ativo = 1;

    if (fwrite(o, sizeof(Ocorrencia), 1, f) != 1) {
        fclose(f);
        return 0;
    }

    fclose(f);
    return 1;
}


/* =====================================================
   FUNÇÃO: db_read
   OBJETIVO: Consultar ocorrência pelo ID
   ===================================================== */
int db_read(int id, Ocorrencia *out) {

    FILE *f = fopen(DB_FILE, "rb");

    if (!f)
        return 0;

    Ocorrencia temp;

    while (fread(&temp, sizeof(Ocorrencia), 1, f) == 1) {

        if (temp.id_ocorrencia == id && temp.ativo == 1) {

            *out = temp;
            fclose(f);
            return 1;
        }
    }

    fclose(f);
    return 0;
}


/* =====================================================
   FUNÇÃO: db_consultar_por_id_e_liberar
   OBJETIVO: Liberar suspeito (versão segura)
   ===================================================== */
int db_consultar_por_id_e_liberar(int id) {

    FILE *f = fopen(DB_FILE, "rb+");

    if (!f)
        return 0;

    Ocorrencia o;

    while (1) {

        long posicao = ftell(f);

        if (fread(&o, sizeof(Ocorrencia), 1, f) != 1)
            break;

        if (o.id_ocorrencia == id && o.ativo == 1) {

            o.status = 1;  // Solto
            o.ativo = 0;   // Inativo

            /* Volta exatamente para o início do registro */
            if (fseek(f, posicao, SEEK_SET) != 0) {
                fclose(f);
                return 0;
            }

            if (fwrite(&o, sizeof(Ocorrencia), 1, f) != 1) {
                fclose(f);
                return 0;
            }

            fclose(f);
            return 1;
        }
    }

    fclose(f);
    return 0;
}
