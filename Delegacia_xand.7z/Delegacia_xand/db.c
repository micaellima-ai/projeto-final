

#include "db.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Inicializa banco */
int db_init(void) {
    FILE *f = fopen(DB_FILE, "ab+");
    if (!f) return 0;
    fclose(f);
    return 1;
}

/* Gerador de ID automático */
int gerador_de_ID(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return 1; // Se arquivo não existe, começa com ID 1

    Ocorrencia o;
    int max_id = 0;
    while (fread(&o, sizeof(Ocorrencia), 1, f)) {
        if (o.id_ocorrencia > max_id)
            max_id = o.id_ocorrencia;
    }
    fclose(f);
    return max_id + 1;
}

/* Cadastrar suspeito */
int db_create(Ocorrencia *o) {
    FILE *f = fopen(DB_FILE, "ab");
    if (!f) return 0;

    o->id_ocorrencia = gerador_de_ID();
    o->ativo = 1;

    fwrite(o, sizeof(Ocorrencia), 1, f);
    fclose(f);
    return 1;
}

/* Consultar por ID */
int db_read(int id, Ocorrencia *out) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return 0;

    Ocorrencia temp;
    while (fread(&temp, sizeof(Ocorrencia), 1, f)) {
        if (temp.id_ocorrencia == id && temp.ativo) {
            *out = temp;
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

/* Liberar suspeito */
int db_consultar_por_id_e_liberar(int id) {
    FILE *f = fopen(DB_FILE, "rb+");
    if (!f) return 0;

    Ocorrencia o;
    while (fread(&o, sizeof(Ocorrencia), 1, f)) {
        if (o.id_ocorrencia == id && o.ativo) {
            // Exibe ficha
            printf("\n=== FICHA DO SUSPEITO ===\n");
            printf("ID: %d\n", o.id_ocorrencia);
            printf("Data: %s\n", o.data_entrada);
            printf("Nome: %s\n", o.nome);
            printf("Crime: %s\n", o.tipo_crime);
            printf("Status: %s\n", o.status == 0 ? "Preso" : "Solto");
            printf("Cela: %d\n", o.cela);

            int opcao;
            printf("\nDeseja libertar este suspeito?\n1 - Sim\n0 - Não\nOpcao: ");
            scanf("%d", &opcao);
            getchar();

            if (opcao == 1) {
                o.status = 1;  // Solto
                o.ativo = 0;   // exclusão lógica
                fseek(f, -(long)sizeof(Ocorrencia), SEEK_CUR);
                fwrite(&o, sizeof(Ocorrencia), 1, f);
                fclose(f);
                printf("\nSuspeito libertado e ficha removida com sucesso.\n");
                return 1;
            }

            fclose(f);
            printf("\nOperação cancelada.\n");
            return 1;
        }
    }

    fclose(f);
    printf("\nOcorrência não encontrada.\n");
    return 0;
}
