#include <stdio.h>   // Biblioteca padrão de entrada e saída (printf, FILE, fopen, etc.)
#include <string.h>  // Biblioteca para manipulação de strings (ex: strcmp)
#include "db.h"      // Header personalizado com a struct Ocorrencia e funções do banco

int main(void) {
    db_init();  // Inicializa o sistema de banco de dados (ex: cria arquivo ou prepara estrutura)

    // Criando três ocorrências com dados pré-definidos
    // Estrutura provável: {id, data, nome, tipo, liberado, prioridade, ativo}
    Ocorrencia o1 = {0, "09/02/2026", "Jose", "Furto", 0, 4, 1};
    Ocorrencia o2 = {0, "10/02/2026", "Pedro", "Roubo", 0, 3, 1};
    Ocorrencia o3 = {0, "11/02/2026", "Mario", "Furto", 0, 3, 1};

    // Inserindo as ocorrências no banco de dados
    // O ID provavelmente é gerado automaticamente (por isso começa com 0)
    db_create(&o1);
    db_create(&o2);
    db_create(&o3);

    // Exibe todas as ocorrências cadastradas
    printf("\n=== LISTA COMPLETA ===\n");
    db_list_all();

    // Exibe as ocorrências ordenadas por ID
    printf("\n=== ORDENADO POR ID ===\n");
    db_list_sorted_by_id();

    // Exibe as ocorrências ordenadas por data
    printf("\n=== ORDENADO POR DATA ===\n");
    db_list_sorted_by_date();

    // Testa a consulta de uma ocorrência pelo ID (2)
    // E em seguida realiza a "liberação" dela (provavelmente altera o campo liberado)
    db_consultar_por_id_e_liberar(2);

    // Mostra novamente a lista após a modificação
    printf("\n=== LISTA ATUALIZADA ===\n");
    db_list_all();

    // Pausa o programa até o usuário pressionar Enter
    printf("\nPressione Enter para sair...");
    getchar();  // Consome possível ENTER pendente
    getchar();  // Aguarda o ENTER do usuário

    return 0;   // Finaliza o programa com sucesso
}
