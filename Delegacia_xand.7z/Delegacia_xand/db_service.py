import os                  # Biblioteca para manipulação de arquivos e diretórios
import pickle              # Usado para salvar e carregar objetos Python em arquivos
from datetime import datetime  # Usado para validar datas

# Nome do arquivo onde os dados serão armazenados
DB_FILE = "delegacia_db.pkl"


# ================= BANCO =================
def iniciar_banco():
    """
    Cria o banco de dados se ele ainda não existir.
    O banco é um arquivo .pkl que armazena uma lista de registros.
    """
    if not os.path.exists(DB_FILE):  # Verifica se o arquivo não existe
        with open(DB_FILE, "wb") as f:  # Cria o arquivo em modo escrita binária
            pickle.dump([], f)  # Inicializa salvando uma lista vazia


# ================= UTIL =================
def carregar_todos():
    """
    Carrega todos os registros do arquivo.
    Retorna uma lista de dicionários.
    """

    # Se o arquivo não existir, retorna lista vazia
    if not os.path.exists(DB_FILE):
        return []

    try:
        with open(DB_FILE, "rb") as f:
            dados = pickle.load(f)  # Carrega os dados serializados

            # Garante compatibilidade caso registros antigos
            # não tenham os campos 'ativo' ou 'status'
            for r in dados:
                if "ativo" not in r:
                    r["ativo"] = True
                if "status" not in r:
                    r["status"] = 0

            return dados

    except Exception:
        # Caso o arquivo esteja corrompido,
        # evita que o programa quebre
        return []


def salvar_todos(registros):
    """
    Salva todos os registros no arquivo,
    sobrescrevendo os dados anteriores.
    """
    with open(DB_FILE, "wb") as f:
        pickle.dump(registros, f)


def gerar_id():
    """
    Gera automaticamente um novo ID.
    Procura o maior ID existente e soma 1.
    """
    registros = carregar_todos()

    if not registros:
        return 1  # Se não houver registros, começa com 1

    return max(r["id"] for r in registros) + 1


def validar_data(data):
    """
    Valida se a data está no formato DD/MM/AAAA
    e se é uma data real.
    """
    try:
        datetime.strptime(data, "%d/%m/%Y")
        return True
    except ValueError:
        return False


# ================= CRUD =================
def inserir_ocorrencia(dia, mes, ano, nome, crime, status, cela):
    """
    Insere uma nova ocorrência no banco,
    realizando validações antes de salvar.
    """

    # Formata a data para DD/MM/AAAA
    data = f"{int(dia):02}/{int(mes):02}/{int(ano):04}"

    # ===== Validações =====
    if not validar_data(data):
        raise ValueError("Data inválida")

    if not nome.strip():
        raise ValueError("Nome vazio")

    if crime not in ["Furto", "Roubo"]:
        raise ValueError("Crime inválido")

    if not (1 <= int(cela) <= 5):
        raise ValueError("Cela inválida (1 a 5)")

    if status not in [0, 1]:
        raise ValueError("Status inválido")

    # Cria o dicionário representando o registro
    registro = {
        "id": gerar_id(),        # ID automático
        "data": data,
        "nome": nome.strip(),
        "crime": crime,
        "status": status,        # 0 = Ativo | 1 = Liberado
        "cela": int(cela),
        "ativo": True            # Exclusão lógica
    }

    # Carrega registros atuais
    registros = carregar_todos()

    # Adiciona novo registro
    registros.append(registro)

    # Salva novamente no arquivo
    salvar_todos(registros)

    return registro["id"]  # Retorna o ID criado


# ================= CONSULTAS =================
def listar_ativos():
    """
    Retorna apenas registros ativos,
    ordenados por ID.
    """
    registros = carregar_todos()

    # Filtra apenas registros ativos
    ativos = [r for r in registros if r.get("ativo", True)]

    # Ordena pelo ID
    return sorted(ativos, key=lambda x: x["id"])


def listar_todos():
    """
    Retorna todos os registros (ativos e inativos),
    ordenados por ID.
    """
    registros = carregar_todos()
    return sorted(registros, key=lambda x: x["id"])


def consultar_por_id(id_):
    """
    Busca um registro específico pelo ID.
    Retorna o dicionário ou None se não encontrar.
    """
    registros = carregar_todos()

    for r in registros:
        if r["id"] == id_:
            return r

    return None


def consultar_e_liberar(id_):
    """
    Consulta um registro pelo ID e realiza
    a liberação (exclusão lógica).
    """

    registros = carregar_todos()

    for r in registros:
        if r["id"] == id_ and r.get("ativo", True):

            # Atualiza status para liberado
            r["status"] = 1

            # Marca como inativo (exclusão lógica)
            r["ativo"] = False

            # Salva alterações
            salvar_todos(registros)

            return True

    return False


# ================= RESET =================
def resetar_banco():
    """
    Apaga todos os registros do banco,
    reinicializando com lista vazia.
    """
    with open(DB_FILE, "wb") as f:
        pickle.dump([], f)
