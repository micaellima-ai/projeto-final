import os
import pickle
from datetime import datetime

DB_FILE = "delegacia_db.pkl"


# ================= BANCO =================
def iniciar_banco():
    """Cria o banco se não existir"""
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, "wb") as f:
            pickle.dump([], f)


# ================= UTIL =================
def carregar_todos():
    """Carrega todos os registros do arquivo"""
    if not os.path.exists(DB_FILE):
        return []

    try:
        with open(DB_FILE, "rb") as f:
            dados = pickle.load(f)

            # Garantir compatibilidade caso falte campo
            for r in dados:
                if "ativo" not in r:
                    r["ativo"] = True
                if "status" not in r:
                    r["status"] = 0

            return dados

    except Exception:
        # Se o arquivo estiver corrompido
        return []


def salvar_todos(registros):
    """Salva todos os registros no arquivo"""
    with open(DB_FILE, "wb") as f:
        pickle.dump(registros, f)


def gerar_id():
    registros = carregar_todos()
    if not registros:
        return 1
    return max(r["id"] for r in registros) + 1


def validar_data(data):
    try:
        datetime.strptime(data, "%d/%m/%Y")
        return True
    except ValueError:
        return False


# ================= CRUD =================
def inserir_ocorrencia(dia, mes, ano, nome, crime, status, cela):
    data = f"{int(dia):02}/{int(mes):02}/{int(ano):04}"

    if not validar_data(data):
        raise ValueError("Data inválida")

    if not nome.strip():
        raise ValueError("Nome vazio")

    if crime not in ["Furto", "Roubo"]:
        raise ValueError("Crime inválido")

    if not (1 <= int(cela) <= 5):
        raise ValueError("Cela inválida (1 a 5)")

    if status not in [0, 1]:
        raise ValueError("Status inválido")

    registro = {
        "id": gerar_id(),
        "data": data,
        "nome": nome.strip(),
        "crime": crime,
        "status": status,   # 0 = Ativo | 1 = Liberado
        "cela": int(cela),
        "ativo": True
    }

    registros = carregar_todos()
    registros.append(registro)
    salvar_todos(registros)

    return registro["id"]


# ================= CONSULTAS =================
def listar_ativos():
    registros = carregar_todos()
    ativos = [r for r in registros if r.get("ativo", True)]
    return sorted(ativos, key=lambda x: x["id"])


def listar_todos():
    registros = carregar_todos()
    return sorted(registros, key=lambda x: x["id"])


def consultar_por_id(id_):
    registros = carregar_todos()
    for r in registros:
        if r["id"] == id_:
            return r
    return None


def consultar_e_liberar(id_):
    registros = carregar_todos()

    for r in registros:
        if r["id"] == id_ and r.get("ativo", True):
            r["status"] = 1
            r["ativo"] = False
            salvar_todos(registros)
            return True

    return False


# ================= RESET =================
def resetar_banco():
    """Apaga todos os registros"""
    with open(DB_FILE, "wb") as f:
        pickle.dump([], f)
