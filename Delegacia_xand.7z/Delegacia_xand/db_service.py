import struct
import os
import ctypes
import sys

# ======================
# CAMINHOS SEGUROS
# ======================

BASE_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
DB_FILE = os.path.join(BASE_DIR, "delegacia.bin")
DLL_PATH = os.path.join(BASE_DIR, "db.dll")

# ======================
# ESTRUTURA DO C
# ======================

class Ocorrencia(ctypes.Structure):
    _fields_ = [
        ("id_ocorrencia", ctypes.c_int),
        ("data_entrada", ctypes.c_char * 11),
        ("nome", ctypes.c_char * 50),
        ("tipo_crime", ctypes.c_char * 20),
        ("status", ctypes.c_int),
        ("cela", ctypes.c_int),
        ("ativo", ctypes.c_int),
    ]


# ======================
# CARREGAR DLL
# ======================

if not os.path.exists(DLL_PATH):
    raise FileNotFoundError("Arquivo db.dll não encontrado!")

dll = ctypes.CDLL(DLL_PATH)

dll.db_create.argtypes = [ctypes.POINTER(Ocorrencia)]
dll.db_create.restype = ctypes.c_int

dll.db_consultar_por_id_e_liberar.argtypes = [ctypes.c_int]
dll.db_consultar_por_id_e_liberar.restype = ctypes.c_int


# ======================
# LEITURA DO BINÁRIO
# ======================

FORMATO = "i11s50s20siii"
TAMANHO = struct.calcsize(FORMATO)


def limpar_string(b):
    """Remove bytes nulos e decodifica com segurança"""
    return b.split(b'\x00', 1)[0].decode("utf-8", errors="ignore")


def carregar_todos():
    registros = []

    if not os.path.exists(DB_FILE):
        return registros

    with open(DB_FILE, "rb") as f:
        while True:
            bloco = f.read(TAMANHO)
            if len(bloco) < TAMANHO:
                break

            dados = struct.unpack(FORMATO, bloco)

            registro = {
                "id": dados[0],
                "data": limpar_string(dados[1]),
                "nome": limpar_string(dados[2]),
                "crime": limpar_string(dados[3]),
                "status": dados[4],
                "cela": dados[5],
                "ativo": dados[6],
            }

            registros.append(registro)

    return registros


def listar_ativos():
    return [r for r in carregar_todos() if r["ativo"] == 1]


def listar_todos():
    return carregar_todos()


def consultar_por_id(id_):
    for r in carregar_todos():
        if r["id"] == id_:
            return r
    return None


# ======================
# INSERÇÃO PELO C
# ======================

def inserir_ocorrencia(dia, mes, ano, nome, crime, status, cela):

    # Validações
    if not (dia and mes and ano and nome and crime and cela):
        raise ValueError("Preencha todos os campos.")

    try:
        data_formatada = f"{int(dia):02}/{int(mes):02}/{int(ano):04}"
        cela = int(cela)
    except ValueError:
        raise ValueError("Data ou cela inválida.")

    ocorrencia = Ocorrencia()
    ocorrencia.id_ocorrencia = 0
    ocorrencia.data_entrada = data_formatada.encode("utf-8").ljust(11, b'\x00')
    ocorrencia.nome = nome.encode("utf-8")[:49].ljust(50, b'\x00')
    ocorrencia.tipo_crime = crime.encode("utf-8")[:19].ljust(20, b'\x00')
    ocorrencia.status = status
    ocorrencia.cela = cela
    ocorrencia.ativo = 1

    resultado = dll.db_create(ctypes.byref(ocorrencia))

    if resultado != 1:
        raise Exception("Erro ao cadastrar ocorrência no C.")

    return True


def consultar_e_liberar(id_):
    try:
        id_ = int(id_)
    except ValueError:
        return False

    resultado = dll.db_consultar_por_id_e_liberar(id_)
    return resultado == 1
